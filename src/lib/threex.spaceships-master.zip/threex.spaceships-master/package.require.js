define( [ 'module'	// to set .baseURL
	, './threex.spaceships'
	], function(module){
	// set baseUrl for this extension
	THREEx.SpaceShips.baseUrl	= module.uri+'/../';
});